﻿Public Class record1
    Public Property id As String
    Public Property idNumber As String
    Public Property ecNumber As String
    Public Property reference As String
    Public Property transDate As String
    Public Property amount As Integer
End Class
