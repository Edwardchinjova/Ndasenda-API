﻿Public Class SSBRegResponse
    Public Property id As String
    Public Property recordsCount As String
    Public Property totalAmount As String
    Public Property deductionCode As Integer
    Public Property status As String
    Public Property creationDate As String
    Public Property records As String

End Class
