﻿Public Class TagId
    Public Property id As Integer
    Public Property active As Boolean
    Public Property isDefault As Boolean
End Class
