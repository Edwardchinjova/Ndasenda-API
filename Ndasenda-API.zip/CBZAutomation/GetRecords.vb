﻿Public Class GetRecords
    Public Property id As String
    Public Property recordsCount As Integer
    Public Property totalAmount As Integer
    Public Property deductionCode As String
    Public Property status As String
    Public Property creationDate As DateTime
    Public Property records As List(Of Record)
End Class
