﻿Public Class GetResponses
    Public Property id As String
    Public Property deductionCode As String
    Public Property recordsCount As Integer
    Public Property totalAmount As Integer
    Public Property creationDate As DateTime

End Class
