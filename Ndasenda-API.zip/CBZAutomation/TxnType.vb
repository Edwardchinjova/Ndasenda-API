﻿Public Class TxnType
    Public Property id As Integer
    Public Property value As String
End Class
