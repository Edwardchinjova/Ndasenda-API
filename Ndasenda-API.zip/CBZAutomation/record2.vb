﻿Public Class record2
    Public Property id As String
    Public Property idNumber As String
    Public Property ecNumber As String
    Public Property type As String
    Public Property reference As String
    'Public Property startdate As String
    'Public Property enddate As String
    Public Property amount As Integer
    Public Property name As String
    Public Property branch As String
    Public Property bankAccount As String
    Public Property totalAmount As Integer
    Public Property status As String
    Public Property message As String
End Class
