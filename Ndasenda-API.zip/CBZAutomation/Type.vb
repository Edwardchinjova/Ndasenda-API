﻿Public Class Type
    Public Property id As Integer
    Public Property code As String
    Public Property value As String
End Class
