﻿Public Class NdasendaToken
    Public Property scope As String
    Public Property token_type As String
    Public Property access_token As String
    Public Property expires_in As Integer
    Public Property refresh_token As String

End Class
