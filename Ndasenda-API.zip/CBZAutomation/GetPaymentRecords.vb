﻿Public Class GetPaymentRecords
    Public Property id As String
    Public Property deductionCode As String
    Public Property creationDate As DateTime
    Public Property recordsCount As Integer
    Public Property totalAmount As Integer
    Public Property records As List(Of record1)

End Class
