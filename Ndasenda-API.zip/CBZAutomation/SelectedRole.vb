﻿Public Class SelectedRole
    Public Property id As Integer
    Public Property name As String
    Public Property description As String
    Public Property disabled As Boolean
End Class
