﻿Public Class Staff
    Public Property id As Integer
    Public Property externalId As String
    Public Property firstname As String
    Public Property lastname As String
    Public Property displayName As String
    Public Property officeId As Integer
    Public Property officeName As String
    Public Property isLoanOfficer As Boolean
    Public Property isActive As Boolean
    Public Property joiningDate As List(Of Integer)
    Public Property userId As Integer
End Class
