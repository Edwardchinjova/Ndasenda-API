﻿Public Class Record
    Public Property id As String
    Public Property idNumber As String
    Public Property ecNumber As String
    Public Property type As String
    Public Property reference As String
    Public Property startDate As String
    Public Property endDate As String
    Public Property amount As Integer
End Class
