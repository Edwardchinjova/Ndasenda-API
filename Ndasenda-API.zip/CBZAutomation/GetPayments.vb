﻿Public Class GetPayments

    Public Property id As String
    Public Property deductionCode As String
    Public Property creationDate As DateTime
    Public Property recordsCount As Integer
    Public Property totalAmount As Integer

End Class
